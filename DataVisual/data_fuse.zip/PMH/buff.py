


import csv
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

import func


def gps_to_x_y(lat_ori, lng0, lat_tar, lng):
    re = 6378135
    rp = 6356750

    t = re * np.cos(lat0) * re * np.cos(lat0) + rp * np.sin(lat0) * rp * np.sin(lat0)
    rns = (re * rp * re * rp) / (t * np.sqrt(t))
    rew = re * re / (np.sqrt(t))

    dLat = lat_tar - lat_ori
    dLng = lng - lng0

    # rns = 6343618.3790280195
    # rew = 6380879.425381593

    r_y = rns * np.sin(dLat)
    r_x = rew * np.sin(dLng) * np.cos(lat0)

    return r_x, r_y


def xy_to_gps(lat_ori, lng0, x_tar, y_tar):
    # dLat = lat - lat0
    # dLng = lng - lng0

    rns = 6343618.3790280195
    rew = 6380879.425381593

    dLat = np.asin(y_tar / rns)
    dLng = np.asin(x_tar / rew / np.cos(lat_ori))

    r_lat = dLat + lat_ori
    r_long = dLng + lng0
    return r_lat, r_long


def distance_cal(r_x, r_y, x_d, y_d):
    return np.sqrt((r_x - x_d) ** 2 + (r_y - y_d) ** 2)


def rad_angle_to_oy(x0, y0, r_x, r_y):
    dx = r_x - x0
    dy = r_y - y0
    dot = dx * 0 + dy * 1
    a = np.sqrt(dx**2 + dy**2)
    b = 1
    if a == 0:
        return 0
    if r_y > 0:
        return np.acos(dot / a)
    else:
        return 2 * np.pi - np.acos(dot / a)



prev_lat = None
prev_lon = None
prev_time = None

########################################################################################

H = np.eye(5)  # transition matrix H, observation model

Qk = np.eye(5) * 0.001  #Qk
P_pred = np.eye(5) * 5
#Noise from measurement
#Assume that error ~ 0.05
Rk = np.eye(5)*0.05  # Rk
# Rk = np.array([[1, 0, 0, 0, 0],
#                [0, 1, 0, 0, 0],
#                [0, 0, 1000, 0, 0],
#                [0, 0, 0, 1000, 0],
#                [0, 0, 0, 0, 0.1]])
########################################################################################


column_names = ['UTIME', 'Fixmode', 'NumberOfSatelines', 'Latitude', 'Longtitude', 'Altitude', 'Track', 'Speed']
gps_data = pd.read_csv('gps.csv', names=column_names)
# Calculate value for GPS
lat0 = gps_data.iloc[0]['Latitude']
lon0 = gps_data.iloc[0]['Longtitude']



# Read IMU data
column_names = ['UTIME', 'Mx', 'My', 'Mz', 'X_a', 'Y_a', 'Z_a', 'X_r', 'Y_r', 'Z_r']
imu_data = pd.read_csv('ms25.csv', names=column_names)
imu_data['X_a'] = pd.to_numeric(imu_data['X_a'], errors='coerce')
imu_data['Z_r'] = pd.to_numeric(imu_data['Z_r'], errors='coerce')

utime = 0
indexOfImu = 2
# x_recorded = []
#
# y_recorded = []
length = 5000

# x_gps = []
# y_gps = []
# x_gps.append(0)
# y_gps.append(0)

x_prev = 0
y_prev = 0

# X_est = np.zeros((5, 1))
X_est = np.array([[0], [0], [0], [0], [np.deg2rad(300)]])
P_est = np.eye(5) * 5
# prev_time_gps = func.time_parser(data['time'])
prev_time_gps = gps_data.iloc[0]['UTIME']
# prev_time = prev_time_gps
Z = X_est

x_bear = []
y_bear = []
x_coord = []
y_coord = []
lat_fused = []
long_fused = []
bearing_arr = []
# bearing_arr.append(300)
bear = np.deg2rad(360 - 90)
index =[]

x = 0
y = 0
x0, y0 = 0, 0
# x_coord.append(x)
# y_coord.append(y)
vx = 0
vy = 0
vx0, vy0 = 0, 0
# a = 0
x_axis = []
vx_arr, vy_arr = [], []
ax_arr, ay_arr = [], []
omega_arr = []
for i in range(100):
    ax = imu_data.iloc[i]['X_a']
    ax = 1
    # ay = imu_data.iloc[i]['Y_a']
    omega = imu_data.iloc[i]['Z_r']
    omega = np.deg2rad(10)

    deltaT = (imu_data.iloc[i]['UTIME'] - imu_data.iloc[i - 1]['UTIME']) / 1000000
    deltaT = 1

    bear = bear + omega * deltaT



    bear %= np.deg2rad(360)
    print(np.rad2deg(bear))

    bearing_arr.append(np.rad2deg(bear))
    bear_e = func.wraptopi(bear)
    # print(f"{bear / np.pi} {bear_e/ np.pi}")
    # head = func.get_heading(imu_data.iloc[i]['Mx'], imu_data.iloc[i]['My'])
    #
    #
    # x += (ax * np.sin(bear_e) - ay * np.cos(bear_e)) * (deltaT ** 2) / 2 + vx * deltaT
    # y += (ax * np.cos(bear_e) + ay * np.sin(bear_e)) * (deltaT ** 2) / 2 + vy * deltaT
    # vx += (ax * np.sin(bear_e) - ay * np.cos(bear_e)) * deltaT
    # vy += (ax * np.cos(bear_e) + ay * np.sin(bear_e)) * deltaT

    x += (ax * np.sin(bear_e)) * (deltaT ** 2) / 2 + vx * deltaT
    y += (ax * np.cos(bear_e)) * (deltaT ** 2) / 2 + vy * deltaT
    vx += (ax * np.sin(bear_e)) * deltaT
    vy += (ax * np.cos(bear_e)) * deltaT
    # x0 = x
    # y0 = y
    # print(f"{vx} {vy}")
    x_coord.append(x)
    y_coord.append(y)
    vx_arr.append(vx)
    # vy_arr.append(vy)
    #
    # x_axis.append(0)
    index.append(i)
    #
    # indexOfImu += 1

plt.plot(x_coord, y_coord, color='blue', label='Raw IMU')
# plt.plot(index, bearing_arr, color='blue', label='Raw IMU')
# plt.plot(x_coord, y_coord, color='blue', label='Raw IMU')
# plt.plot(x_gps, y_gps, color="red", label='Raw GPS')
# plt.xlabel('X')
# plt.ylabel('Y')
# plt.title('(X, Y)')

# x_rtk = []
# y_rtk = []

# count = 0
# with open('rtk_xy.txt', 'r') as file:
#     for line in file:
#         if count >= 350:
#             break
#         fields = line.strip().split(' ')
#         x_rtk.append(float(fields[0]))
#         y_rtk.append(float(fields[1]))
#         count = count + 1

# plt.plot(x_rtk, y_rtk, color='green', label='RTK-GPS(pseudo-groundtruth)')
# bearing_rad = np.deg2rad(bearing_arr)
# bearing_rad = bearing_arr
# plt.quiver(x_coord, y_coord, np.sin(bearing_rad), np.cos(bearing_rad), angles='xy', scale_units='xy', scale=0.005, color='red')

# plt.xlabel('X Coordinate')
# plt.ylabel('Y Coordinate')
# plt.title('Scatter Plot of Points')
# plt.xlim(-30, 5)
# plt.ylim(-30, 5)

plt.figure()
plt.plot(index, x_coord, color='green', label='Coord')
plt.plot(index, bearing_arr, color='cyan', label='Heading')
plt.plot(index, vx_arr, color='red', label='Velocity')
# plt.plot(index, ax_arr, color='blue', label='Acceleration')
# plt.plot(index, x_axis, color='black', label='Axis')
plt.legend()
plt.title('IMU x-axis')

# plt.figure()
# # plt.plot(index, omega_arr, color='green', label='Angular')
# # # plt.plot(index, ax_arr, color='cyan', label='Ax')
# # plt.plot(index, ay_arr, color='red', label='Ay')
# # plt.plot(index, ax_arr, color='blue', label='Acceleration')
# # plt.plot(index, x_axis, color='black', label='Axis')
# plt.legend()
# plt.title('IMU x-axis')


#
# plt.figure()
# plt.plot(index, y_coord, color='green', label='Coord')
# plt.plot(index, vy_arr, color='red', label='Velocity')
# plt.plot(index, ay_arr, color='blue', label='Acceleration')
# plt.plot(index, x_axis, color='black', label='Axis')
# plt.legend()
# plt.title('IMU y-axis')

# plt.figure()
#
# plt.legend()
# # plt.plot(index, y_coord, color='green', label='Heading')
# plt.title('heading')

plt.legend()
plt.show()





