import csv
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

import func





def xy_to_gps(lat_ori, lng0, x_tar, y_tar):
    # dLat = lat - lat0
    # dLng = lng - lng0

    rns = 6343618.3790280195
    rew = 6380879.425381593

    dLat = np.asin(y_tar / rns)
    dLng = np.asin(x_tar / rew / np.cos(lat_ori))

    r_lat = dLat + lat_ori
    r_long = dLng + lng0
    return r_lat, r_long


def distance_cal(r_x, r_y, x_d, y_d):
    return np.sqrt((r_x - x_d) ** 2 + (r_y - y_d) ** 2)






prev_lat = None
prev_lon = None
prev_time = None

########################################################################################

H = np.eye(5)  # transition matrix H, observation model

Qk = np.eye(5) * 0.001  #Qk
P_pred = np.eye(5) * 5
#Noise from measurement
#Assume that error ~ 0.05
Rk = np.eye(5)*0.05  # Rk
# Rk = np.array([[0.05, 0, 0, 0, 0],
#                [0, 0.00001, 0, 0, 0],
#                [0, 0, 1, 0, 0],
#                [0, 0, 0, 1, 0],
#                [0, 0, 0, 0, 0.1]])
########################################################################################
column_names = ['UTIME', 'Fixmode', 'NumberOfSatelines', 'Latitude', 'Longtitude', 'Altitude', 'Track', 'Speed']
gps_data = pd.read_csv('gps_rtk.csv', names=column_names)
# Calculate value for GPS
lat0 = gps_data.iloc[0]['Latitude']
lon0 = gps_data.iloc[0]['Longtitude']


column_names = ['UTIME', 'Mx', 'My', 'Mz', 'X_a', 'Y_a', 'Z_a', 'X_r', 'Y_r', 'Z_r']
imu_data = pd.read_csv('ms25.csv', names=column_names)
imu_data['X_a'] = pd.to_numeric(imu_data['X_a'], errors='coerce')
imu_data['Z_r'] = pd.to_numeric(imu_data['Z_r'], errors='coerce')

utime = 0
indexOfImu = 2
x_recorded = []

y_recorded = []
length = 5000

x_gps = []
y_gps = []
x_gps.append(0)
y_gps.append(0)

x_prev = 0
y_prev = 0

# X_est = np.zeros((5, 1))
X_est = np.array([[0], [0], [0], [0], [np.deg2rad(300)]])
X_pred = X_est
P_est = np.eye(5) * 5
# prev_time_gps = func.time_parser(data['time'])
prev_time_gps = gps_data.iloc[0]['UTIME']
# prev_time = prev_time_gps
Z = X_est

x_bear = []
y_bear = []
x_coord = []
y_coord = []
lat_fused = []
long_fused = []
bearing_arr = []
# bearing_arr.append(300)
bear = np.deg2rad(300)
error =[]
x_previous, y_previous = 0, 0
# x_previous.append(0)
# x_previous.append(0)
for i in range(1, 350): # Iterate through GPS data
    # if (gps_data.iloc[i]['Fixmode'] == 2 or gps_data.iloc[i]['Fixmode'] == 3):
    utime = gps_data.iloc[i]['UTIME']
    lat = gps_data.iloc[i]['Latitude']
    lon = gps_data.iloc[i]['Longtitude']
    # get previous x and y
    x, y = func.gps_to_x_y(lat0, lon0, lat, lon)
    # check if robot not move so skip calculate angle.
    # if x != x_previous:
    #     angle = np.arctan((y - y_previous) / (x - x_previous))
    # else:
    #     if y != y_previous:
    #         angle = np.pi / 2  # 90 degrees if x and x_previous are the same but y is different
    #     else:
    #         continue  # use previous state if both x and y are the same

    vx = gps_data.iloc[i]['Speed']

    if pd.isna(vx):  # check if vx is number or NaN
        vx = gps_data.iloc[i + 1]['Speed']

    # utime += 1
    while utime > imu_data.iloc[indexOfImu]['UTIME']:
        deltaT = (imu_data.iloc[indexOfImu]['UTIME'] - imu_data.iloc[indexOfImu - 1]['UTIME']) / 1000000

        ax = imu_data.iloc[indexOfImu - 1]['X_a']
        omega = imu_data.iloc[indexOfImu - 1]['Z_r']
        X_pred, P_pred = func.kalman_predict(X_pred, P_pred, Qk, ax, omega, deltaT)
        # print(np.rad2deg(omega))
        indexOfImu += 4
        x_coord.append(X_pred[0][0])
        y_coord.append(X_pred[1][0])
        # print(indexOfImu)

    if x != x_previous and y != y_previous:
        prev_time_gps = utime
        deltaT_gps = (gps_data.iloc[i]['UTIME'] - gps_data.iloc[i - 1]['UTIME']) / (10 ** 6)
        theta = func.rad_angle_to_oy(x_previous, y_previous, x, y)
        x_gps.append(x)
        y_gps.append(y)
        # bearing_arr.append(theta)
        theta_w = func.wraptopi(theta)
        # theta_w = theta
        # Z = np.array([[x], [y], [(x - x_previous) / deltaT_gps], [(y - y_previous) / deltaT_gps], [theta]])
        Z = np.array([[x], [y], [vx * np.sin(theta)], [vx * np.cos(theta_w)], [theta]])
        X_pred, P_pred = func.kalman_update(X_pred, P_pred, H, Rk, Z)
        x_previous, y_previous = x, y
        x_coord.append(X_pred[0][0])
        y_coord.append(X_pred[1][0])

    # X_est = X_pred
    # P_est = P_pred




plt.plot(x_coord, y_coord, color='blue', label='Fused')
plt.plot(x_gps, y_gps, color="red", label='Raw GPS')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('(X, Y)')

x_rtk = []
y_rtk = []

count = 0
with open('rtk_xy.txt', 'r') as file:
    for line in file:
        if count >= 350:
            break
        fields = line.strip().split(' ')
        x_rtk.append(float(fields[0]))
        y_rtk.append(float(fields[1]))
        count = count + 1

# plt.plot(x_rtk, y_rtk, color='green', label='RTK-GPS(pseudo-groundtruth)')
# bearing_rad = np.deg2rad(bearing_arr)
bearing_rad = bearing_arr
# plt.quiver(x_coord, y_coord, np.sin(bearing_rad), np.cos(bearing_rad), angles='xy', scale_units='xy', scale=0.05, color='red')

plt.xlabel('X Coordinate')
plt.ylabel('Y Coordinate')
plt.title('Scatter Plot of Points')
# plt.xlim(-30, 5)
# plt.ylim(-30, 5)
# plt.gca().invert_yaxis()

plt.legend()

plt.show()





