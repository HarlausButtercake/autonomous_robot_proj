import numpy as np
import func

angle = 360 - 90
angle = np.deg2rad(angle)
angle = func.wraptopi(angle)
# angle = func.rad_angle_to_oy(0, 0, 3, 3)
print(np.sin(angle)) #
# print(angle)