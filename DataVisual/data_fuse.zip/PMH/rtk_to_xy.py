import pandas as pd
import func

# Convert geographical coordinates from RTK GPS (ground truth) to xy

if __name__ == "__main__":
    column_names = ['UTIME', 'Fixmode', 'NumberOfSatelines', 'Latitude', 'Longitude', 'Altitude', 'Track', 'Speed']
    gps_data = pd.read_csv('gps_rtk.csv', names=column_names)
    x_rtk, y_rtk = [], []
    #
    lat0, lon0 = gps_data.iloc[0]['Latitude'], gps_data.iloc[0]['Longitude']
    for i in range(2000): # Range
        x, y = func.gps_to_x_y(lat0, lon0, gps_data.iloc[i]['Latitude'], gps_data.iloc[i]['Longitude'])
        x_rtk.append(x)
        y_rtk.append(y)


    with open('rtk_xy.txt', 'w') as file:
        xbuf = 9999
        ybuf = 9999
        for x_val, y_val in zip(x_rtk, y_rtk):
            # print(f"{x_val} {y_val}")
            if xbuf != x_val or ybuf != y_val:
                file.write(f"{x_val} {y_val}\n")
                # xbuf = x_val
                # ybuf = y_val