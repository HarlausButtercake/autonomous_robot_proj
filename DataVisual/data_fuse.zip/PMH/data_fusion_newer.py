import csv
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

import func


def xy_to_gps(lat_ori, lng0, x_tar, y_tar):
    # dLat = lat - lat0
    # dLng = lng - lng0

    rns = 6343618.3790280195
    rew = 6380879.425381593

    dLat = np.asin(y_tar / rns)
    dLng = np.asin(x_tar / rew / np.cos(lat_ori))

    r_lat = dLat + lat_ori
    r_long = dLng + lng0
    return r_lat, r_long







prev_lat = None
prev_lon = None
prev_time = None

########################################################################################

H = np.eye(5)  # transition matrix H, observation model

Qk = np.eye(5) * 0.001  #Qk
P_pred = np.eye(5) * 5
#Noise from measurement
#Assume that error ~ 0.05
# Rk = np.eye(5)*0.05  # Rk
Rk = np.array([[10, 0, 0, 0, 0],
               [0, 10, 0, 0, 0],
               [0, 0, 1000, 0, 0],
               [0, 0, 0, 1000, 0],
               [0, 0, 0, 0, 0.1]])
########################################################################################
# file_name = 'final_data.csv'
# begin = 0
# data = {
#                 'time',
#                 'lat',
#                 'lon',
#                 'Ax',
#                 'Ay',
#                 'Gz',
#                 'bearing'
#             }
# with open(file_name, newline='') as csvfile:
#     csvreader = csv.reader(csvfile)
#     for i, row in enumerate(csvreader):
#         if i == 0:
#             data = {
#                 'time': row[0],
#                 'lat': float(row[1]),
#                 'lon': float(row[2]),
#                 'Ax': float(row[3]),
#                 'Ay': float(row[4]),
#                 'Gz': float(row[5]),
#                 'bearing': float(row[6])
#             }

column_names = ['UTIME', 'Fixmode', 'NumberOfSatelines', 'Latitude', 'Longtitude', 'Altitude', 'Track', 'Speed']
gps_data = pd.read_csv('gps.csv', names=column_names)
# Calculate value for GPS
lat0 = gps_data.iloc[0]['Latitude']
lon0 = gps_data.iloc[0]['Longtitude']



# Read IMU data
column_names = ['UTIME', 'Mx', 'My', 'Mz', 'X_a', 'Y_a', 'Z_a', 'X_r', 'Y_r', 'Z_r']
imu_data = pd.read_csv('ms25.csv', names=column_names)
imu_data['X_a'] = pd.to_numeric(imu_data['X_a'], errors='coerce')
imu_data['Z_r'] = pd.to_numeric(imu_data['Z_r'], errors='coerce')

utime = 0
indexOfImu = 2
x_recorded = []

y_recorded = []
length = 5000

x_gps = []
y_gps = []
x_gps.append(0)
y_gps.append(0)

x_prev = 0
y_prev = 0

# X_est = np.zeros((5, 1))
X_est = np.array([[0], [0], [0], [0], [np.deg2rad(300)]])
P_est = np.eye(5) * 5
# prev_time_gps = func.time_parser(data['time'])
prev_time_gps = gps_data.iloc[0]['UTIME']
# prev_time = prev_time_gps
Z = X_est

x_bear = []
y_bear = []
x_coord = []
y_coord = []
lat_fused = []
long_fused = []
bearing_arr = []
# bearing_arr.append(300)
bear = np.deg2rad(300)
error =[]
for i in range(1, 900, 3):
    # if (gps_data.iloc[i]['Fixmode'] == 2 or gps_data.iloc[i]['Fixmode'] == 3):
    utime = gps_data.iloc[i]['UTIME']
    lat = gps_data.iloc[i]['Latitude']
    lon = gps_data.iloc[i]['Longtitude']
    # get previous x and y
    x, y = func.gps_to_x_y(lat0, lon0, lat, lon)

    x_previous = x_gps[-1]
    y_previous = y_gps[-1]

    vx = gps_data.iloc[i]['Speed']

    if pd.isna(vx):  # check if vx is number or NaN
        vx = gps_data.iloc[i + 1]['Speed']

    while utime > imu_data.iloc[indexOfImu]['UTIME']:
        # prev_time = imu_data.iloc[indexOfImu]['UTIME']
        deltaT = (imu_data.iloc[indexOfImu]['UTIME'] - imu_data.iloc[indexOfImu - 1]['UTIME']) / 1000000

        ax = imu_data.iloc[indexOfImu - 1]['X_a']
        omega = imu_data.iloc[indexOfImu - 1]['Z_r']
        # X_pred, P_pred = func.kalman_predict(X_est, P_pred, Qk, ax, np.deg2rad(omega), deltaT)
        X_pred, P_pred = func.kalman_predict(X_est, P_pred, Qk, ax, omega, deltaT)

        indexOfImu += 1

        # X_est = X_pred
        # P_est = P_pred

        print(indexOfImu)
        bearing_arr.append(X_est[4][0])
        # x_coord.append(X_est[0][0])
        # y_coord.append(X_est[1][0])

    # update matrix

    # deltaT_gps = (utime - prev_time_gps) # / (10 ** 6)
    deltaT_gps = (gps_data.iloc[i]['UTIME'] - gps_data.iloc[i - 1]['UTIME']) / (10 ** 6)
    prev_time_gps = utime
    if x != x_previous and y != y_previous:
        theta = func.rad_angle_to_oy(x_previous, y_previous, x, y)

        x_gps.append(x)
        y_gps.append(y)
        # bearing_arr.append(theta)
        theta_w = func.wraptopi(theta)
        # theta_w = theta
        Z = np.array([[x], [y], [(x - x_previous) / deltaT_gps], [(y - y_previous) / deltaT_gps], [theta]])
        # Z = np.array([[x], [y], [vx * np.sin(theta_w)], [vx * np.cos(theta_w)], [theta]])
    X_pred, P_pred = func.kalman_update(X_pred, P_pred, H, Rk, Z)

    X_est = X_pred
    P_est = P_pred
    x_coord.append(X_est[0][0])
    y_coord.append(X_est[1][0])


plt.plot(x_coord, y_coord, color='blue', label='Fused')
plt.plot(x_gps, y_gps, color="red", label='Raw GPS')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('(X, Y)')

x_rtk = []
y_rtk = []
x_rtk.append(0)
y_rtk.append(0)
index = [0]
head = [0]
count = 0
xp = 0
yp = 0
with open('rtk_xy.txt', 'r') as file:
    for line in file:
        if count <= 350:
            fields = line.strip().split(' ')
            # if x_rtk[-1] != float(fields[0]) or y_rtk[-1] != float(fields[1]):

            x_rtk.append(float(fields[0]))
            y_rtk.append(float(fields[1]))
            # if xp != x_rtk[-1] or yp != y_rtk[-1]:
            head.append(func.rad_angle_to_oy(xp, yp, x_rtk[-1], y_rtk[-1]))
            xp = x_rtk[-1]
            yp = y_rtk[-1]
            index.append(count)
            count = count + 1


plt.plot(x_rtk, y_rtk, color='green', label='RTK-GPS (pseudo-groundtruth)', s=1)
# bearing_rad = np.deg2rad(bearing_arr)
# bearing_rad = bearing_arr
# plt.quiver(x_rtk, y_rtk, np.sin(head), np.cos(head), angles='xy', scale_units='xy', scale=1, color='red')

plt.xlabel('X Coordinate')
plt.ylabel('Y Coordinate')
plt.title('Scatter Plot of Points')
# plt.xlim(-30, 5)
# plt.ylim(-30, 5)
# plt.gca().invert_yaxis()

plt.legend()

# plt.figure()
# # plt.plot(index, x_coord, color='green', label='Coord')
# # plt.plot(index, np.rad2deg(head), color='cyan', label='Heading')
# # plt.plot(index, vx_arr, color='red', label='Velocity')
# # plt.plot(index, ax_arr, color='blue', label='Acceleration')
# # plt.plot(index, x_axis, color='black', label='Axis')
# plt.legend()
# plt.title('IMU x-axis')


plt.show()





