import csv
import numpy as np
import time

from matplotlib import pyplot as plt

import func


# def get_F(delta):
#     F = np.array([[1, 0, delta, 0],
#                   [0, 1, 0, delta],
#                   [0, 0, 1, 0],
#                   [0, 0, 0, 1]])
#     return F


# def kalman_predict(X0, P0, l_Qk, Fk, l_ax, l_ay, t):
#     m = t ** 2 / 2
#     B1 = np.array([[m * l_ax],
#                    [m * l_ay],
#                    [t * l_ax],
#                    [t * l_ay]])
#     B2 = np.array([[0], [0], [0], [0]])
#     Xp = Fk.dot(X0) + B1 + B2
#
#     Pp = (Fk.dot(P0)).dot(Fk.T) + l_Qk
#     return Xp, Pp

def get_F(delta):
    F = np.array([[1, 0, delta, 0, (delta ** 2) / 2, 0, 0],    # x
                  [0, 1, 0, delta, 0, (delta ** 2) / 2, 0],    # y
                  [0, 0, 1, 0, delta, 0, 0],                        # vx
                  [0, 0, 0, 1, 0, delta, 0],                       # vx
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 1]])                       # theta
    return F


def kalman_predict(X0, P0, l_Qk, Fk, l_ax, l_ay, w, t):
    m = t ** 2 / 2
    B1 = np.array([[0],
                   [0],
                   [0],
                   [0],
                   [l_ax],
                   [l_ay],
                   [t * w]])
    # B2 = np.array([[0], [0], [0], [0]])
    Xp = Fk.dot(X0) + B1

    Pp = (Fk.dot(P0)).dot(Fk.T) + l_Qk
    return Xp, Pp


def kalman_update(xp_loc, pp_loc, hk_loc, rk_loc, zk_loc):
    K = (pp_loc.dot(hk_loc.T)).dot(np.linalg.inv((hk_loc.dot(pp_loc)).dot(hk_loc.T) + rk_loc))
    r_x = xp_loc + K.dot((zk_loc - hk_loc.dot(xp_loc)))
    r_p = pp_loc - K.dot((hk_loc.dot(pp_loc)))
    return r_x, r_p


def gps_to_x_y(lat_ori, lng0, lat_tar, lng):
    dLat = lat_tar - lat_ori
    dLng = lng - lng0

    rns = 6343618.3790280195
    rew = 6380879.425381593

    y = rns * np.sin(dLat)
    x = rew * np.sin(dLng) * np.cos(lat0)

    return x, y


def xy_to_gps(lat_ori, lng0, x_tar, y_tar):
    # dLat = lat - lat0
    # dLng = lng - lng0

    rns = 6343618.3790280195
    rew = 6380879.425381593

    dLat = np.asin(y_tar / rns)
    dLng = np.asin(x_tar / rew / np.cos(lat_ori))

    r_lat = dLat + lat_ori
    r_long = dLng + lng0
    return r_lat, r_long


def distance_cal(x, y, x_d, y_d):
    return np.sqrt((x - x_d) ** 2 + (y - y_d) ** 2)


prev_lat = None
prev_lon = None
prev_time = None

########################################################################################

# Qk_coeff = 1
# p_coeff = 0.5
# # Rk_coeff = [1, 1, 0.4, 0.01]
# Rk_coeff = 0.5
#
# Qk = np.eye(4) * Qk_coeff  # Cov of process noise
# P = np.eye(4) * p_coeff  # State CoV
# # Rk = np.diag(Rk_coeff)  # CoV of observation noise
# Rk = np.eye(4) * Rk_coeff
H = np.eye(7)  # transition matrix H, observation model

Qk = np.eye(7) * 0.001 #Qk
P = np.eye(7) * 5
#Noise from measurement
#Assume that error ~ 0.05
#Rk = np.eye(4)*0.05 #Rk
# Rk = np.array([[0.1, 0, 0, 0],
#                [0, 0.1, 0, 0],
#                 [0, 0, 5, 0],
#                [0, 0, 0, 5]])

Rk = np.array([[10, 0, 0, 0, 0, 0, 0],    # x
                  [0, 10, 0, 0, 0, 0, 0],    # y
                  [0, 0, 2, 0, 0, 0, 0],                        # vx
                  [0, 0, 0, 2, 0, 0, 0],                       # vx
                  [0, 0, 0, 0, 2, 0, 0],
                  [0, 0, 0, 0, 0, 2, 0],
                  [0, 0, 0, 0, 0, 0, 0.2]])

########################################################################################
file_name = '../Log_ULIS_France_Straight.csv'
begin = 540

data = func.to_data(file_name, begin)
lat0, lon0 = func.coord_to_rad(data['lat']), func.coord_to_rad(data['lon'])


data = func.to_data(file_name, begin + 30)
lat, lon = func.coord_to_rad(data['lat']), func.coord_to_rad(data['lon'])

x, y = gps_to_x_y(lat0, lon0, lat, lon)

x_p = x
y_p = y

X = np.zeros((7, 1))
# Z = np.array([[x_p], [y_p], [x/3], [y/3]])
Z = np.array([[x], [y], [x / 3], [y / 3], [data['Ax_lin']], [data['Ay_lin']], [data['Gz'] + 0.23]])
X, P = kalman_update(X, P, H, Rk, Z)
# vx_prev = 0
# vy_prev = 0
# v_prev = v
prev_time_gps = func.time_parser(data['time'])

x_geo = []
y_geo = []
x_coord = []
y_coord = []
lat_fused = []
long_fused = []
bearing_arr = []
with open(file_name, newline='') as csvfile:
    csvreader = csv.reader(csvfile)
    for i, row in enumerate(csvreader):
        if i >= begin + 31 - 1:
            data = {
                'time': row[0],
                'lat': float(row[1]),
                'lon': float(row[2]),
                'Ax': float(row[3]),
                'Ay': float(row[4]),
                'Ax_lin': float(row[5]),
                'Ay_lin': float(row[6]),
                'Gz': float(row[7]),
                'bearing': float(row[8])
            }
            deltaT_gps = func.time_parser(data['time']) - prev_time_gps
            if deltaT_gps >= 1:
                lat, lon = func.coord_to_rad(data['lat']), func.coord_to_rad(data['lon'])
                x, y = gps_to_x_y(lat0, lon0, lat, lon)
                # v = np.sqrt((x - x_p) ** 2 + (y - y_p) ** 2) / deltaT_gps
                theta = np.arctan2((y - y_p), (x - x_p))
                Z = np.array([[x], [y], [x - x_p], [y - y_p], [ax], [ay], [theta]])
                X, P = kalman_update(X, P, H, Rk, Z)
                prev_time_gps = func.time_parser(data['time'])
                x_p = x
                y_p = y
                x_geo.append(x)
                y_geo.append(y)

            ax, ay, w = data['Ax_lin'], data['Ay_lin'], data['bearing']
            # if np.abs(ax) < 0.1: _lin
            #     ax = 0
            # if np.abs(ay) < 0.1:
            #     ay = 0
            current_time = func.time_parser(data['time'])
            deltaT = 0.1

            # buf = ax
            # ax = ay
            # ay = buf
            # ax = -ax
            # ay = 0
            # ax = 1
            F = get_F(deltaT)
            X, P = kalman_predict(X, P, Qk, F, ax, ay, w + 0.23, deltaT)

            x_coord.append(X[0][0])
            y_coord.append(X[1][0])
            blat, blong = xy_to_gps(lat0, lon0, X[0][0], X[1][0])
            lat_fused.append(np.rad2deg(blat))
            long_fused.append(np.rad2deg(blong))
            # bearing_arr.append(w)

with open('../../RemoteController/set.txt', 'w') as file:
    xbuf = 9999
    ybuf = 9999
    for x_val, y_val in zip(lat_fused, long_fused):
        # print(f"{x_val} {y_val}")
        if xbuf != x_val or ybuf != y_val:
            file.write(f"{x_val} {y_val}\n")
            xbuf = x_val
            ybuf = y_val

plt.plot(x_coord, y_coord, color='blue', label='Fused xy')
plt.plot(x_geo, y_geo, color='red', label='GPS xy')

# bearing_rad = np.deg2rad(bearing_arr)
# plt.quiver(x_coord, y_coord, np.sin(bearing_rad), np.cos(bearing_rad), angles='xy', scale_units='xy', scale=0.5, color='red')

plt.xlabel('X Coordinate')
plt.ylabel('Y Coordinate')
plt.title('Scatter Plot of Points')
plt.xlim(-30, 30)
# plt.gca().invert_yaxis()

plt.legend()

plt.show()





